-- CreateTable
CREATE TABLE "ScheduleDefinitionUserSite" (
    "id" TEXT NOT NULL,
    "scheduleDefinitionId" TEXT NOT NULL,
    "userSiteId" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "deleted_at" TIMESTAMP(3),
    "updated_by" TEXT,

    CONSTRAINT "ScheduleDefinitionUserSite_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ScheduleDefinitionUserSite_scheduleDefinitionId_userSiteId_key" ON "ScheduleDefinitionUserSite"("scheduleDefinitionId", "userSiteId");

-- AddForeignKey
ALTER TABLE "ScheduleDefinitionUserSite" ADD CONSTRAINT "ScheduleDefinitionUserSite_scheduleDefinitionId_fkey" FOREIGN KEY ("scheduleDefinitionId") REFERENCES "ScheduleDefinition"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ScheduleDefinitionUserSite" ADD CONSTRAINT "ScheduleDefinitionUserSite_userSiteId_fkey" FOREIGN KEY ("userSiteId") REFERENCES "UserSite"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
