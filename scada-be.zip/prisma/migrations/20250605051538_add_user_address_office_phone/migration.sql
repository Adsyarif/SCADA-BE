/*
  Warnings:

  - The `phone_number` column on the `User` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - A unique constraint covering the columns `[nik]` on the table `User` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "User" ADD COLUMN     "address" TEXT,
ADD COLUMN     "nik" TEXT,
ADD COLUMN     "office_phone_number" INTEGER,
DROP COLUMN "phone_number",
ADD COLUMN     "phone_number" INTEGER;

-- CreateIndex
CREATE UNIQUE INDEX "User_nik_key" ON "User"("nik");
