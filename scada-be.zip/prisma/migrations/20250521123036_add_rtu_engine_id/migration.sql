/*
  Warnings:

  - Added the required column `rtuEngineId` to the `RtuConfiguration` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "RtuConfiguration" ADD COLUMN     "rtuEngineId" TEXT NOT NULL;
