/*
  Warnings:

  - You are about to drop the `Schedule` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "Schedule" DROP CONSTRAINT "Schedule_shiftId_fkey";

-- DropForeignKey
ALTER TABLE "Schedule" DROP CONSTRAINT "Schedule_userId_fkey";

-- DropTable
DROP TABLE "Schedule";

-- CreateTable
CREATE TABLE "ScheduleDefinition" (
    "id" TEXT NOT NULL,
    "rtuId" TEXT NOT NULL,
    "shiftId" TEXT NOT NULL,
    "daysOfWeek" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "deleted_at" TIMESTAMP(3),
    "updated_by" TEXT,

    CONSTRAINT "ScheduleDefinition_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ScheduleDefinition_rtuId_shiftId_daysOfWeek_key" ON "ScheduleDefinition"("rtuId", "shiftId", "daysOfWeek");

-- AddForeignKey
ALTER TABLE "ScheduleDefinition" ADD CONSTRAINT "ScheduleDefinition_rtuId_fkey" FOREIGN KEY ("rtuId") REFERENCES "RtuConfiguration"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ScheduleDefinition" ADD CONSTRAINT "ScheduleDefinition_shiftId_fkey" FOREIGN KEY ("shiftId") REFERENCES "Shift"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
