-- AlterTable
ALTER TABLE "UserSite" ADD COLUMN     "checkInStatus" BOOLEAN NOT NULL DEFAULT false;
