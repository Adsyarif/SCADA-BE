-- AlterTable
ALTER TABLE "User" ALTER COLUMN "office_phone_number" SET DATA TYPE TEXT,
ALTER COLUMN "phone_number" SET DATA TYPE TEXT;
